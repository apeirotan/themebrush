
<link href="{!! asset('themes/bare-bootstrap/css/styles.css') !!}" rel="stylesheet">