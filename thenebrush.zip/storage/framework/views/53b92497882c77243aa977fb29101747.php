<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <?php echo $__env->yieldPushContent('meta'); ?>
        <?php echo $__env->yieldPushContent('open-graph'); ?>
        <?php echo $__env->yieldPushContent('twitter-card'); ?>
        <?php echo $__env->yieldPushContent('json-ld'); ?>
        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        <?php echo $__env->make('themes.'.env('APP_THEME').'.vite-styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           <?php echo $__env->yieldPushContent('styles'); ?>
    </head>
    <body class="antialiased">
        <?php echo $__env->make('themes.'.env('APP_THEME').'.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('themes.'.env('APP_THEME').'.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--================= Footer End Here =================-->
<?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\thenebrush\resources\views/layouts/public.blade.php ENDPATH**/ ?>