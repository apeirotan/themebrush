<?php echo app('Illuminate\Foundation\Vite')(['public/assets/css/main.css', 
'public/assets/css/all.min.css',

'public/assets/css/rt-icons.css',

'public/assets/css/animate.min.css',

'public/assets/css/magnific-popup.css',

'public/assets/css/swiper-bundle.min.css',

'public/assets/css/metisMenu.css',

'public/assets/css/preloader.css',

'public/assets/css/rtsmenu.css',

'public/assets/css/variables/variable3.css',

'public/assets/css/style.css']); ?><?php /**PATH C:\xampp\htdocs\thenebrush\resources\views/themes/tsolkashome_gr/vite-styles.blade.php ENDPATH**/ ?>